PRAGMA foreign_keys=OFF;
BEGIN TRANSACTION;
CREATE TABLE works (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        title TEXT NOT NULL,
                        title_kana TEXT,
                        title_en TEXT,
                        type TEXT CHECK(type IN ('anime','manga')),
                        official_url TEXT,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                    );
INSERT INTO works VALUES(229,'葬送のフリーレン','そうそうのふりーれん','Frieren: Beyond Journey''s End','anime','https://frieren-anime.jp/','2025-11-14 13:56:07');
INSERT INTO works VALUES(230,'薬屋のひとりごと','くすりやのひとりごと','The Apothecary Diaries','anime','https://kusuriyanohitorigoto.jp/','2025-11-14 13:56:07');
INSERT INTO works VALUES(231,'僕のヒーローアカデミア','ぼくのひーろーあかでみあ','My Hero Academia','anime','https://heroaca.com/','2025-11-14 13:56:07');
INSERT INTO works VALUES(232,'SPY×FAMILY','すぱいふぁみりー','Spy x Family','anime','https://spy-family.net/','2025-11-14 13:56:07');
INSERT INTO works VALUES(233,'【推しの子】','おしのこ','Oshi no Ko','anime','https://ichigoproduction.com/','2025-11-14 13:56:07');
INSERT INTO works VALUES(234,'ダンジョン飯','だんじょんめし','Delicious in Dungeon','anime','https://delicious-in-dungeon.com/','2025-11-14 13:56:07');
INSERT INTO works VALUES(235,'呪術廻戦','じゅじゅつかいせん','Jujutsu Kaisen','anime','https://jujutsukaisen.jp/','2025-11-14 13:56:07');
INSERT INTO works VALUES(236,'ワンピース','わんぴーす','One Piece','manga','https://one-piece.com/','2025-11-14 13:56:07');
INSERT INTO works VALUES(237,'チェンソーマン','ちぇんそーまん','Chainsaw Man','manga','https://chainsawman.net/','2025-11-14 13:56:08');
INSERT INTO works VALUES(238,'スパイファミリー','すぱいふぁみりー','Spy x Family','manga','https://spy-family.net/','2025-11-14 13:56:08');
INSERT INTO works VALUES(239,'僕のヒーローアカデミア','ぼくのひーろーあかでみあ','My Hero Academia','manga','https://heroaca.com/','2025-11-14 13:56:08');
INSERT INTO works VALUES(240,'怪獣8号','かいじゅうはちごう','Kaiju No.8','manga','https://kj8.jp/','2025-11-14 13:56:08');
CREATE TABLE releases (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        work_id INTEGER NOT NULL,
                        release_type TEXT CHECK(release_type IN ('episode','volume')),
                        number TEXT,
                        platform TEXT,
                        release_date DATE,
                        source TEXT,
                        source_url TEXT,
                        notified INTEGER DEFAULT 0,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        FOREIGN KEY (work_id) REFERENCES works (id) ON DELETE CASCADE,
                        UNIQUE(work_id, release_type, number, platform, release_date)
                    );
INSERT INTO releases VALUES(305,229,'episode','29','dアニメストア','2025-11-15','sample_data','https://frieren-anime.jp/',0,'2025-11-14 13:56:07');
INSERT INTO releases VALUES(306,229,'episode','30','dアニメストア','2025-11-22','sample_data','https://frieren-anime.jp/',0,'2025-11-14 13:56:07');
INSERT INTO releases VALUES(307,230,'episode','25','Netflix','2025-11-16','sample_data','https://kusuriyanohitorigoto.jp/',0,'2025-11-14 13:56:07');
INSERT INTO releases VALUES(308,230,'episode','26','Netflix','2025-11-23','sample_data','https://kusuriyanohitorigoto.jp/',0,'2025-11-14 13:56:07');
INSERT INTO releases VALUES(309,231,'episode','151','dアニメストア','2025-11-17','sample_data','https://heroaca.com/',0,'2025-11-14 13:56:07');
INSERT INTO releases VALUES(310,231,'episode','152','dアニメストア','2025-11-24','sample_data','https://heroaca.com/',0,'2025-11-14 13:56:07');
INSERT INTO releases VALUES(311,232,'episode','38','Amazon Prime','2025-11-18','sample_data','https://spy-family.net/',0,'2025-11-14 13:56:07');
INSERT INTO releases VALUES(312,233,'episode','25','dアニメストア','2025-11-19','sample_data','https://ichigoproduction.com/',0,'2025-11-14 13:56:07');
INSERT INTO releases VALUES(313,234,'episode','25','Netflix','2025-11-20','sample_data','https://delicious-in-dungeon.com/',0,'2025-11-14 13:56:07');
INSERT INTO releases VALUES(314,235,'episode','48','dアニメストア','2025-11-21','sample_data','https://jujutsukaisen.jp/',0,'2025-11-14 13:56:07');
INSERT INTO releases VALUES(315,236,'volume','108','BookWalker','2025-11-16','sample_data','https://one-piece.com/',0,'2025-11-14 13:56:08');
INSERT INTO releases VALUES(316,236,'volume','108','Kindle','2025-11-16','sample_data','https://one-piece.com/',0,'2025-11-14 13:56:08');
INSERT INTO releases VALUES(317,237,'volume','17','BookWalker','2025-11-19','sample_data','https://chainsawman.net/',0,'2025-11-14 13:56:08');
INSERT INTO releases VALUES(318,238,'volume','14','Kindle','2025-11-21','sample_data','https://spy-family.net/',0,'2025-11-14 13:56:08');
INSERT INTO releases VALUES(319,239,'volume','40','BookWalker','2025-11-24','sample_data','https://heroaca.com/',0,'2025-11-14 13:56:08');
INSERT INTO releases VALUES(320,240,'volume','13','BookWalker','2025-11-26','sample_data','https://kj8.jp/',0,'2025-11-14 13:56:08');
INSERT INTO releases VALUES(321,230,'episode','26','Netflix','2025-12-16','sample_data',NULL,0,'2025-11-16 05:41:05');
INSERT INTO releases VALUES(322,236,'volume','109','BookWalker','2025-12-16','sample_data',NULL,0,'2025-11-16 05:41:05');
INSERT INTO releases VALUES(323,236,'volume','109','Kindle','2025-12-16','sample_data',NULL,0,'2025-11-16 05:41:05');
INSERT INTO releases VALUES(324,231,'episode','152','dアニメストア','2025-12-17','sample_data',NULL,0,'2025-11-16 05:41:05');
INSERT INTO releases VALUES(325,232,'episode','39','Amazon Prime','2025-12-18','sample_data',NULL,0,'2025-11-16 05:41:05');
INSERT INTO releases VALUES(326,233,'episode','26','dアニメストア','2025-12-19','sample_data',NULL,0,'2025-11-16 05:41:05');
INSERT INTO releases VALUES(327,237,'volume','18','BookWalker','2025-12-19','sample_data',NULL,0,'2025-11-16 05:41:05');
INSERT INTO releases VALUES(328,234,'episode','26','Netflix','2025-12-20','sample_data',NULL,0,'2025-11-16 05:41:05');
INSERT INTO releases VALUES(329,235,'episode','49','dアニメストア','2025-12-21','sample_data',NULL,0,'2025-11-16 05:41:05');
INSERT INTO releases VALUES(330,238,'volume','15','Kindle','2025-12-21','sample_data',NULL,0,'2025-11-16 05:41:05');
INSERT INTO releases VALUES(331,230,'episode','27','Netflix','2026-01-16','sample_data',NULL,0,'2025-11-16 05:41:11');
INSERT INTO releases VALUES(332,236,'volume','110','BookWalker','2026-01-16','sample_data',NULL,0,'2025-11-16 05:41:11');
INSERT INTO releases VALUES(333,236,'volume','110','Kindle','2026-01-16','sample_data',NULL,0,'2025-11-16 05:41:11');
INSERT INTO releases VALUES(334,231,'episode','153','dアニメストア','2026-01-17','sample_data',NULL,0,'2025-11-16 05:41:11');
INSERT INTO releases VALUES(335,232,'episode','40','Amazon Prime','2026-01-18','sample_data',NULL,0,'2025-11-16 05:41:11');
INSERT INTO releases VALUES(336,233,'episode','27','dアニメストア','2026-01-19','sample_data',NULL,0,'2025-11-16 05:41:11');
INSERT INTO releases VALUES(337,237,'volume','19','BookWalker','2026-01-19','sample_data',NULL,0,'2025-11-16 05:41:11');
INSERT INTO releases VALUES(338,234,'episode','27','Netflix','2026-01-20','sample_data',NULL,0,'2025-11-16 05:41:11');
INSERT INTO releases VALUES(339,235,'episode','50','dアニメストア','2026-01-21','sample_data',NULL,0,'2025-11-16 05:41:11');
INSERT INTO releases VALUES(340,238,'volume','16','Kindle','2026-01-21','sample_data',NULL,0,'2025-11-16 05:41:11');
ANALYZE sqlite_schema;
INSERT INTO sqlite_stat1 VALUES('works','idx_works_type','12 6');
INSERT INTO sqlite_stat1 VALUES('works','idx_works_title','12 1');
INSERT INTO sqlite_stat1 VALUES('releases','idx_releases_notified','36 36');
INSERT INTO sqlite_stat1 VALUES('releases','idx_releases_date','36 2');
INSERT INTO sqlite_stat1 VALUES('releases','idx_releases_work_id','36 3');
INSERT INTO sqlite_stat1 VALUES('releases','sqlite_autoindex_releases_1','36 3 3 2 1 1');
INSERT INTO sqlite_stat1 VALUES('settings','idx_settings_key','6 1');
INSERT INTO sqlite_stat1 VALUES('settings','sqlite_autoindex_settings_1','6 1');
INSERT INTO sqlite_stat1 VALUES('notification_history','idx_type_success','5 3 2');
INSERT INTO sqlite_stat1 VALUES('notification_history','idx_created_at','5 2');
INSERT INTO sqlite_stat1 VALUES('notification_history','idx_notification_history_executed_at','5 2');
INSERT INTO sqlite_stat1 VALUES('notification_history','idx_notification_history_type','5 3');
INSERT INTO sqlite_stat1 VALUES('calendar_events','idx_calendar_events_created_at','35 18');
INSERT INTO sqlite_stat1 VALUES('calendar_events','idx_calendar_events_work_id','35 3');
INSERT INTO sqlite_stat1 VALUES('calendar_events','idx_calendar_events_date','35 2');
INSERT INTO sqlite_stat1 VALUES('collection_stats','idx_collection_stats_updated_at','17 9');
INSERT INTO sqlite_stat1 VALUES('collection_stats','idx_collection_stats_source_id','17 1');
INSERT INTO sqlite_stat1 VALUES('collection_stats','sqlite_autoindex_collection_stats_1','17 1');
CREATE TABLE settings (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        key TEXT UNIQUE NOT NULL,
                        value TEXT,
                        value_type TEXT CHECK(value_type IN ('string','integer','boolean','json')),
                        description TEXT,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
                    );
INSERT INTO settings VALUES(1,'notification_email','kensan1969@gmail.com','string','デフォルト通知先メールアドレス','2025-11-15 03:37:09','2025-11-15 12:13:51');
INSERT INTO settings VALUES(2,'check_interval_hours','1','integer','チェック間隔（時間）','2025-11-15 03:37:09','2025-11-15 12:13:51');
INSERT INTO settings VALUES(3,'email_notifications_enabled','true','boolean','メール通知を有効化','2025-11-15 03:37:09','2025-11-15 12:13:51');
INSERT INTO settings VALUES(4,'calendar_enabled','false','boolean','カレンダー登録を有効化','2025-11-15 03:37:09','2025-11-15 12:13:51');
INSERT INTO settings VALUES(5,'max_notifications_per_day','50','integer','1日あたりの最大通知数','2025-11-15 03:37:09','2025-11-15 12:13:51');
INSERT INTO settings VALUES(25,'test_setting','test_value','string','テスト設定','2025-11-15 03:38:28','2025-11-15 03:38:28');
CREATE TABLE notification_history (
                        id INTEGER PRIMARY KEY AUTOINCREMENT,
                        notification_type TEXT CHECK(notification_type IN ('email','calendar')),
                        executed_at DATETIME DEFAULT CURRENT_TIMESTAMP,
                        success INTEGER DEFAULT 1,
                        error_message TEXT,
                        releases_count INTEGER DEFAULT 0,
                        created_at DATETIME DEFAULT CURRENT_TIMESTAMP
                    , details TEXT, metadata TEXT);
INSERT INTO notification_history VALUES(1,'email','2025-11-15 06:03:56',1,NULL,3,'2025-11-15 06:03:56','テスト: 3件のメール送信',NULL);
INSERT INTO notification_history VALUES(2,'calendar','2025-11-15 06:03:56',1,NULL,2,'2025-11-15 06:03:56','テスト: 2件のカレンダー登録','{"platform": "Google Calendar"}');
INSERT INTO notification_history VALUES(3,'email','2025-11-15 06:07:27',1,NULL,10,'2025-11-15 06:07:27','10件のメール送信成功','{"smtp_server": "smtp.gmail.com"}');
INSERT INTO notification_history VALUES(4,'calendar','2025-11-15 06:07:28',1,NULL,8,'2025-11-15 06:07:28','8件のカレンダーイベント登録','{"calendar_id": "primary"}');
INSERT INTO notification_history VALUES(5,'email','2025-11-15 06:07:28',0,'SMTP authentication error',0,'2025-11-15 06:07:28','送信失敗',NULL);
CREATE TABLE calendar_events (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    work_id INTEGER NOT NULL,
    release_id INTEGER,
    event_title TEXT NOT NULL,
    event_date DATE NOT NULL,
    description TEXT,
    location TEXT,
    calendar_id TEXT,
    event_id TEXT,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (work_id) REFERENCES works(id),
    FOREIGN KEY (release_id) REFERENCES releases(id)
);
INSERT INTO calendar_events VALUES(1,230,307,'薬屋のひとりごと 第25話 [Netflix]','2025-11-16',replace('作品: 薬屋のひとりごと\n種類: anime\nリリース種類: episode\n番号: 25\nプラットフォーム: Netflix\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:25:47','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(2,236,315,'ワンピース 第108巻 [BookWalker]','2025-11-16',replace('作品: ワンピース\n種類: manga\nリリース種類: volume\n番号: 108\nプラットフォーム: BookWalker\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:25:47','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(3,236,316,'ワンピース 第108巻 [Kindle]','2025-11-16',replace('作品: ワンピース\n種類: manga\nリリース種類: volume\n番号: 108\nプラットフォーム: Kindle\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:25:47','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(4,231,309,'僕のヒーローアカデミア 第151話 [dアニメストア]','2025-11-17',replace('作品: 僕のヒーローアカデミア\n種類: anime\nリリース種類: episode\n番号: 151\nプラットフォーム: dアニメストア\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:25:47','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(5,232,311,'SPY×FAMILY 第38話 [Amazon Prime]','2025-11-18',replace('作品: SPY×FAMILY\n種類: anime\nリリース種類: episode\n番号: 38\nプラットフォーム: Amazon Prime\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:25:47','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(6,233,312,'【推しの子】 第25話 [dアニメストア]','2025-11-19',replace('作品: 【推しの子】\n種類: anime\nリリース種類: episode\n番号: 25\nプラットフォーム: dアニメストア\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:25:47','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(7,237,317,'チェンソーマン 第17巻 [BookWalker]','2025-11-19',replace('作品: チェンソーマン\n種類: manga\nリリース種類: volume\n番号: 17\nプラットフォーム: BookWalker\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:25:47','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(8,234,313,'ダンジョン飯 第25話 [Netflix]','2025-11-20',replace('作品: ダンジョン飯\n種類: anime\nリリース種類: episode\n番号: 25\nプラットフォーム: Netflix\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:25:47','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(9,235,314,'呪術廻戦 第48話 [dアニメストア]','2025-11-21',replace('作品: 呪術廻戦\n種類: anime\nリリース種類: episode\n番号: 48\nプラットフォーム: dアニメストア\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:25:47','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(10,238,318,'スパイファミリー 第14巻 [Kindle]','2025-11-21',replace('作品: スパイファミリー\n種類: manga\nリリース種類: volume\n番号: 14\nプラットフォーム: Kindle\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:25:47','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(11,229,306,'葬送のフリーレン 第30話 [dアニメストア]','2025-11-22',replace('作品: 葬送のフリーレン\n種類: anime\nリリース種類: episode\n番号: 30\nプラットフォーム: dアニメストア\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:25:47','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(12,230,308,'薬屋のひとりごと 第26話 [Netflix]','2025-11-23',replace('作品: 薬屋のひとりごと\n種類: anime\nリリース種類: episode\n番号: 26\nプラットフォーム: Netflix\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:25:47','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(13,231,310,'僕のヒーローアカデミア 第152話 [dアニメストア]','2025-11-24',replace('作品: 僕のヒーローアカデミア\n種類: anime\nリリース種類: episode\n番号: 152\nプラットフォーム: dアニメストア\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:25:47','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(14,239,319,'僕のヒーローアカデミア 第40巻 [BookWalker]','2025-11-24',replace('作品: 僕のヒーローアカデミア\n種類: manga\nリリース種類: volume\n番号: 40\nプラットフォーム: BookWalker\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:25:47','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(15,240,320,'怪獣8号 第13巻 [BookWalker]','2025-11-26',replace('作品: 怪獣8号\n種類: manga\nリリース種類: volume\n番号: 13\nプラットフォーム: BookWalker\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:25:47','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(16,230,321,'薬屋のひとりごと 第26話 [Netflix]','2025-12-16',replace('作品: 薬屋のひとりごと\n種類: anime\nリリース種類: episode\n番号: 26\nプラットフォーム: Netflix\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:41:22','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(17,236,322,'ワンピース 第109巻 [BookWalker]','2025-12-16',replace('作品: ワンピース\n種類: manga\nリリース種類: volume\n番号: 109\nプラットフォーム: BookWalker\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:41:22','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(18,236,323,'ワンピース 第109巻 [Kindle]','2025-12-16',replace('作品: ワンピース\n種類: manga\nリリース種類: volume\n番号: 109\nプラットフォーム: Kindle\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:41:22','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(19,231,324,'僕のヒーローアカデミア 第152話 [dアニメストア]','2025-12-17',replace('作品: 僕のヒーローアカデミア\n種類: anime\nリリース種類: episode\n番号: 152\nプラットフォーム: dアニメストア\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:41:22','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(20,232,325,'SPY×FAMILY 第39話 [Amazon Prime]','2025-12-18',replace('作品: SPY×FAMILY\n種類: anime\nリリース種類: episode\n番号: 39\nプラットフォーム: Amazon Prime\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:41:22','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(21,233,326,'【推しの子】 第26話 [dアニメストア]','2025-12-19',replace('作品: 【推しの子】\n種類: anime\nリリース種類: episode\n番号: 26\nプラットフォーム: dアニメストア\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:41:22','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(22,237,327,'チェンソーマン 第18巻 [BookWalker]','2025-12-19',replace('作品: チェンソーマン\n種類: manga\nリリース種類: volume\n番号: 18\nプラットフォーム: BookWalker\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:41:22','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(23,234,328,'ダンジョン飯 第26話 [Netflix]','2025-12-20',replace('作品: ダンジョン飯\n種類: anime\nリリース種類: episode\n番号: 26\nプラットフォーム: Netflix\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:41:22','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(24,235,329,'呪術廻戦 第49話 [dアニメストア]','2025-12-21',replace('作品: 呪術廻戦\n種類: anime\nリリース種類: episode\n番号: 49\nプラットフォーム: dアニメストア\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:41:22','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(25,238,330,'スパイファミリー 第15巻 [Kindle]','2025-12-21',replace('作品: スパイファミリー\n種類: manga\nリリース種類: volume\n番号: 15\nプラットフォーム: Kindle\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:41:22','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(26,230,331,'薬屋のひとりごと 第27話 [Netflix]','2026-01-16',replace('作品: 薬屋のひとりごと\n種類: anime\nリリース種類: episode\n番号: 27\nプラットフォーム: Netflix\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:41:22','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(27,236,332,'ワンピース 第110巻 [BookWalker]','2026-01-16',replace('作品: ワンピース\n種類: manga\nリリース種類: volume\n番号: 110\nプラットフォーム: BookWalker\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:41:22','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(28,236,333,'ワンピース 第110巻 [Kindle]','2026-01-16',replace('作品: ワンピース\n種類: manga\nリリース種類: volume\n番号: 110\nプラットフォーム: Kindle\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:41:22','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(29,231,334,'僕のヒーローアカデミア 第153話 [dアニメストア]','2026-01-17',replace('作品: 僕のヒーローアカデミア\n種類: anime\nリリース種類: episode\n番号: 153\nプラットフォーム: dアニメストア\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:41:22','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(30,232,335,'SPY×FAMILY 第40話 [Amazon Prime]','2026-01-18',replace('作品: SPY×FAMILY\n種類: anime\nリリース種類: episode\n番号: 40\nプラットフォーム: Amazon Prime\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:41:22','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(31,233,336,'【推しの子】 第27話 [dアニメストア]','2026-01-19',replace('作品: 【推しの子】\n種類: anime\nリリース種類: episode\n番号: 27\nプラットフォーム: dアニメストア\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:41:22','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(32,237,337,'チェンソーマン 第19巻 [BookWalker]','2026-01-19',replace('作品: チェンソーマン\n種類: manga\nリリース種類: volume\n番号: 19\nプラットフォーム: BookWalker\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:41:22','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(33,234,338,'ダンジョン飯 第27話 [Netflix]','2026-01-20',replace('作品: ダンジョン飯\n種類: anime\nリリース種類: episode\n番号: 27\nプラットフォーム: Netflix\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:41:22','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(34,235,339,'呪術廻戦 第50話 [dアニメストア]','2026-01-21',replace('作品: 呪術廻戦\n種類: anime\nリリース種類: episode\n番号: 50\nプラットフォーム: dアニメストア\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:41:22','2025-11-16 05:41:22');
INSERT INTO calendar_events VALUES(35,238,340,'スパイファミリー 第16巻 [Kindle]','2026-01-21',replace('作品: スパイファミリー\n種類: manga\nリリース種類: volume\n番号: 16\nプラットフォーム: Kindle\nソース: sample_data','\n',char(10)),NULL,NULL,NULL,'2025-11-16 05:41:22','2025-11-16 05:41:22');
CREATE TABLE error_logs (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    category TEXT CHECK(category IN ('notification', 'calendar', 'collection', 'system')),
    message TEXT NOT NULL,
    stack_trace TEXT,
    severity TEXT CHECK(severity IN ('low', 'medium', 'high', 'critical')),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
CREATE TABLE collection_stats (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    source_id TEXT NOT NULL UNIQUE,
    source_name TEXT NOT NULL,
    source_type TEXT CHECK(source_type IN ('api','rss')) NOT NULL,
    total_attempts INTEGER DEFAULT 0,
    successful_attempts INTEGER DEFAULT 0,
    failed_attempts INTEGER DEFAULT 0,
    items_collected INTEGER DEFAULT 0,
    last_run DATETIME,
    last_success DATETIME,
    last_error TEXT,
    success_rate REAL DEFAULT 0.0,
    avg_response_time REAL DEFAULT 0.0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP
);
INSERT INTO collection_stats VALUES(1,'anilist','AniList GraphQL API','api',150,148,2,2340,'2025-11-16 14:45:54','2025-11-16 08:35:24',NULL,98.6700000000000017,1.19999999999999995,'2025-11-15 22:42:19','2025-11-16 14:45:54');
INSERT INTO collection_stats VALUES(2,'syoboi','しょぼいカレンダー','api',120,115,5,1850,'2025-11-16 14:45:54','2025-11-16 08:29:24',NULL,95.8299999999999982,2.10000000000000008,'2025-11-15 22:42:19','2025-11-16 14:45:54');
INSERT INTO collection_stats VALUES(3,'kitsu','Kitsu API','api',135,132,3,2100,'2025-11-16 14:45:54','2025-11-16 08:34:24',NULL,97.7800000000000011,1.5,'2025-11-15 22:42:19','2025-11-16 14:45:54');
INSERT INTO collection_stats VALUES(4,'annict','Annict','api',0,0,0,0,'2025-11-16 14:45:54',NULL,NULL,100.0,0.0,'2025-11-15 22:42:19','2025-11-16 14:45:54');
INSERT INTO collection_stats VALUES(5,'mangadex','MangaDex API','api',200,195,5,3500,'2025-11-16 14:45:54','2025-11-16 08:28:24',NULL,97.5,1.80000000000000004,'2025-11-15 22:42:19','2025-11-16 14:45:54');
INSERT INTO collection_stats VALUES(6,'mangaupdates','MangaUpdates API','api',180,175,5,2900,'2025-11-16 14:45:54','2025-11-16 08:36:24',NULL,97.2199999999999988,1.60000000000000008,'2025-11-15 22:42:19','2025-11-16 14:45:54');
INSERT INTO collection_stats VALUES(7,'myanimelist_news','MyAnimeList News','rss',50,48,2,580,'2025-11-16 14:46:02','2025-11-16 08:36:24',NULL,96.0,2.0,'2025-11-15 22:42:19','2025-11-16 14:46:02');
INSERT INTO collection_stats VALUES(8,'crunchyroll_anime_news','Crunchyroll Anime News','rss',50,49,1,620,'2025-11-16 14:46:02','2025-11-16 08:33:24',NULL,98.0,1.80000000000000004,'2025-11-15 22:42:19','2025-11-16 14:46:02');
INSERT INTO collection_stats VALUES(9,'anime_uk_news','Anime UK News','rss',50,47,3,550,'2025-11-16 14:46:02','2025-11-16 08:31:24',NULL,94.0,2.20000000000000017,'2025-11-15 22:42:19','2025-11-16 14:46:02');
INSERT INTO collection_stats VALUES(10,'otaku_news','Otaku News','rss',50,48,2,570,'2025-11-16 14:46:02','2025-11-16 08:32:24',NULL,96.0,2.0,'2025-11-15 22:42:19','2025-11-16 14:46:02');
INSERT INTO collection_stats VALUES(11,'マンバ','マンバ','rss',60,59,1,720,'2025-11-16 14:46:02','2025-11-16 08:29:24',NULL,98.3299999999999982,1.89999999999999991,'2025-11-15 22:42:19','2025-11-16 14:46:02');
INSERT INTO collection_stats VALUES(12,'マンバ通信','マンバ通信','rss',55,54,1,650,'2025-11-16 14:46:02','2025-11-16 08:32:24',NULL,98.1800000000000068,2.0,'2025-11-15 22:42:19','2025-11-16 14:46:02');
INSERT INTO collection_stats VALUES(13,'マンバ_クチコミ','マンバ クチコミ','rss',45,44,1,530,'2025-11-16 14:46:02','2025-11-16 08:29:24',NULL,97.7800000000000011,2.10000000000000008,'2025-11-15 22:42:19','2025-11-16 14:46:02');
INSERT INTO collection_stats VALUES(14,'マンバ_無料キャンペーン','マンバ 無料キャンペーン','rss',40,39,1,480,'2025-11-16 14:46:02','2025-11-16 08:35:24',NULL,97.5,2.0,'2025-11-15 22:42:19','2025-11-16 14:46:02');
INSERT INTO collection_stats VALUES(15,'マンバ公式note','マンバ公式note','rss',35,34,1,420,'2025-11-16 14:46:02','2025-11-16 08:35:24',NULL,97.1400000000000005,1.89999999999999991,'2025-11-15 22:42:19','2025-11-16 14:46:02');
INSERT INTO collection_stats VALUES(16,'leed_cafe','LEED Cafe','rss',30,29,1,350,'2025-11-16 14:46:02','2025-11-16 08:31:24',NULL,96.6700000000000017,2.0,'2025-11-15 22:42:19','2025-11-16 14:46:02');
INSERT INTO collection_stats VALUES(17,'少年ジャンプ+','少年ジャンプ+','rss',45,44,1,540,'2025-11-16 14:46:02','2025-11-16 08:37:24',NULL,97.7800000000000011,1.80000000000000004,'2025-11-15 22:42:19','2025-11-16 14:46:02');
DELETE FROM sqlite_sequence;
INSERT INTO sqlite_sequence VALUES('works',240);
INSERT INTO sqlite_sequence VALUES('releases',340);
INSERT INTO sqlite_sequence VALUES('settings',505);
INSERT INTO sqlite_sequence VALUES('notification_history',5);
INSERT INTO sqlite_sequence VALUES('collection_stats',17);
INSERT INTO sqlite_sequence VALUES('calendar_events',35);
CREATE INDEX idx_works_title ON works(title);
CREATE INDEX idx_works_type ON works(type);
CREATE INDEX idx_releases_work_id ON releases(work_id);
CREATE INDEX idx_releases_date ON releases(release_date);
CREATE INDEX idx_releases_notified ON releases(notified);
CREATE INDEX idx_settings_key ON settings(key);
CREATE INDEX idx_notification_history_type ON notification_history(notification_type);
CREATE INDEX idx_notification_history_executed_at ON notification_history(executed_at);
CREATE INDEX idx_created_at
                ON notification_history(created_at DESC)
            ;
CREATE INDEX idx_type_success
                ON notification_history(notification_type, success)
            ;
CREATE INDEX idx_calendar_events_date ON calendar_events(event_date);
CREATE INDEX idx_calendar_events_work_id ON calendar_events(work_id);
CREATE INDEX idx_calendar_events_created_at ON calendar_events(created_at DESC);
CREATE INDEX idx_error_logs_category ON error_logs(category);
CREATE INDEX idx_error_logs_created_at ON error_logs(created_at DESC);
CREATE INDEX idx_collection_stats_source_id ON collection_stats(source_id);
CREATE INDEX idx_collection_stats_updated_at ON collection_stats(updated_at DESC);
COMMIT;
